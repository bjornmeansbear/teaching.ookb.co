A Three-Hour Tour of After Effects Recommended Websites: http://www.videocopilot.net/tutorials/ Special effects more than motion graphics but still amazing tutorialshttp://www.lynda.com/ Everything you ever wanted to know about everything digital. Use this while it is free!http://www.creativecow.net/  Diverse set of tutorials on AE and other programs
http://www.greyscalegorilla.com/blog/tutorials/software/after-effects/  A lot of good basic stuff for AE.# Topics Covered:
- Importing:
File > Import > as composition if you need access to your PSD layers, footage flattens it- Composition:
Standard TV NTSC 720 x 480 3:2 aspect ratio/ 1280 x 720 16:9. 30 FPS; remember to choose square pixels… Computer= square- Title / Action Safe:
Guides for production, insures important info isn’t cropped off- Layers: 
Similar to Photoshop. 
Create new layer= Layer > new layer > select type- Layer styles: 
drop shadow, bevel glow etc. layer> layer styles- Keyframing: 
remember to include both a start and an end value. Virtually any value can be keyframed.- Keyframing assistant: 
smoothes out motion paths for more natural movement > Rt click keyframe- Transform: 
standard transform tools for each layer include anchor point, position, scale, rotate, opacity.- Masks: 
Simply draw the shape on the layer. Make sure the layer you want to mask is selected otherwise you will make new shape layer. - Effects: 
loads of effects and plug-ins. The heart of AE- Text / presets:
Animation> Browse presets> opens Bridge> selection in bridge transfers to selected AE layer- Parenting Layers: 
transfers one layer’s scale and rotation to another’s

- Null Object:
Useful as a way to have an invisible thing to parent other things to… still gets "transform" properties.- Nesting: 
places one composition inside of another. Essentially flattens the composition- The wiggler: 
Creates jitter between keyframes Window> Wiggler- Export: 
Render Queue - Composition> make movie> Lossless / h.264… check the audio box too